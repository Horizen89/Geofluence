layer_obs = iface.activeLayer()
layer_even = QgsProject.instance().mapLayersByName('Evenement')[0]
layer_form = QgsProject.instance().mapLayersByName('Form_EEE')[0]
feat_obs = layer_obs.selectedFeatures()
feat_even = ''
feat_form = ''

Index_ID = ''
Liste_ID_Obs = []
Liste_ID_Even = []
Liste_ID_Form = []

# Choix de la méthode
#layer.selectByExpression(expression, QgsVectorLayer.AddSelection)
#QgsVectorLayer.SetSelection
#QgsVectorLayer.RemoveSelection

for f in feat_obs:
    Index_ID = f.fields().indexFromName('ID_OBS')
    Liste_ID_Obs.append(f.attribute(Index_ID))

geom_type = ''
tmp_geom = feat_obs[0].geometry()
wkb_type = tmp_geom.wkbType()
if QgsWkbTypes.displayString(wkb_type) == 'Point':
    geom_type = 'P'
if QgsWkbTypes.displayString(wkb_type) == 'Polygon':
    geom_type = 'S'
if QgsWkbTypes.displayString(wkb_type) == 'LineString':
    geom_type = 'L'

separator = '\', \''
Texte_Obs = separator.join(Liste_ID_Obs)
layer_even.selectByExpression("\"ID_OBS_"+geom_type+"\" IN ('"+Texte_Obs+"')")
feat_even = layer_even.selectedFeatures()
for f in feat_even:
    Index_ID = f.fields().indexFromName('ID_EVEN')
    Liste_ID_Even.append(f.attribute(Index_ID))

separator = '\', \''
Texte_Even = separator.join(Liste_ID_Even)
layer_form.selectByExpression("\"ID_EVEN\" IN ('"+Texte_Even+"')")
feat_form = layer_form.selectedFeatures()
for f in feat_form:
    Index_ID = f.fields().indexFromName('ID_EEE')
    Liste_ID_Form.append(f.attribute(Index_ID))