
def classFactory(iface):
    from .update_dom_plugin import UpdateDomPlugin
    return UpdateDomPlugin(iface)