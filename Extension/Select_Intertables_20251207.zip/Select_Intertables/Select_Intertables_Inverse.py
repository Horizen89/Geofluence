layer_form = iface.activeLayer()
layer_even = QgsProject.instance().mapLayersByName('Evenement')[0]
layer_obs_p = QgsProject.instance().mapLayersByName('Observation_Point')[0]
layer_obs_s = QgsProject.instance().mapLayersByName('Observation_Polygone')[0]
layer_obs_l = QgsProject.instance().mapLayersByName('Observation_Ligne')[0]

feat_obs_p = ''
feat_obs_s = ''
feat_obs_l = ''
feat_even = ''
feat_form = layer_form.selectedFeatures()

Index_ID = ''
Liste_ID_Obs = []
Liste_ID_Even_P = []
Liste_ID_Even_S = []
Liste_ID_Even_L = []
Liste_ID_Form = []

# Choix de la méthode
#layer.selectByExpression(expression, QgsVectorLayer.AddSelection)
#QgsVectorLayer.SetSelection
#QgsVectorLayer.RemoveSelection

for f in feat_form:
    Index_ID = f.fields().indexFromName('ID_EVEN')
    Liste_ID_Form.append(f.attribute(Index_ID))

separator = '\', \''
Texte_Form = separator.join(Liste_ID_Form)
layer_even.selectByExpression("\"ID_EVEN\" IN ('"+Texte_Form+"')")
feat_even = layer_even.selectedFeatures()
for f in feat_even:
    #Pour le moment, ne fonctionne que pour les points. Il faudrait fouiller les 3 colonnes.
    Index_ID = f.fields().indexFromName('ID_OBS_P')
    Liste_ID_Even_P.append(f.attribute(Index_ID))
    Index_ID = f.fields().indexFromName('ID_OBS_S')
    Liste_ID_Even_S.append(f.attribute(Index_ID))
    Index_ID = f.fields().indexFromName('ID_OBS_L')
    Liste_ID_Even_L.append(f.attribute(Index_ID))

separator = '\', \''
try:
    Texte_Even_P = separator.join(Liste_ID_Even_P)
    layer_obs_p.selectByExpression("\"ID_OBS\" IN ('"+Texte_Even_P+"')")
    feat_obs_p = layer_obs_p.selectedFeatures()
except:
    print('Aucune observation de type Point ne correspond à la sélection')
try:
    Texte_Even_S = separator.join(Liste_ID_Even_S)
    layer_obs_s.selectByExpression("\"ID_OBS\" IN ('"+Texte_Even_S+"')")
    feat_obs_s = layer_obs_s.selectedFeatures()
except:
    print('Aucune observation de type Polygone ne correspond à la sélection')
try:
    Texte_Even_L = separator.join(Liste_ID_Even_L)
    layer_obs_l.selectByExpression("\"ID_OBS\" IN ('"+Texte_Even_L+"')")
    feat_obs_l = layer_obs_l.selectedFeatures()
except:
    print('Aucune observation de type Ligne ne correspond à la sélection')