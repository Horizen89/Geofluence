from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QPushButton, QCheckBox, QMessageBox, QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject, NULL
from collections import defaultdict

class UpdateDomWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Calculer la dominance des espèces végétales")
        self.setMinimumWidth(450)
        self.setLayout(QVBoxLayout())

        # Case à cocher pour appliquer le calcul aux entités sélectionnées
        self.selection_only_checkbox = QCheckBox("Appliquer seulement aux entités sélectionnées")
        self.layout().addWidget(self.selection_only_checkbox)

        # Bouton pour lancer le calcul
        self.update_button = QPushButton("Lancer le calcul")
        self.update_button.clicked.connect(self.run_update)
        self.layout().addWidget(self.update_button)

    def run_update(self):
        layer = QgsProject.instance().mapLayersByName("FormSect_SP_Veget")
        if not layer:
            QMessageBox.critical(self, "Erreur", "La couche 'FormSect_SP_Veget' n'est pas trouvée dans le projet.")
            return

        layer = layer[0]

        # Vérifier si la couche est modifiable
        if not layer.isEditable():
            layer.startEditing()

        try:
            apply_to_selection_only = self.selection_only_checkbox.isChecked()
            features = list(layer.selectedFeatures() if apply_to_selection_only else layer.getFeatures())

            if not features:
                QMessageBox.warning(self, "Attention", "Aucune entité concernée pour le calcul.")
                return

            # Étape 0 : Réinitialisation du recouvrement relatif (forcer la mise à jour du calcul)
            print('etape0')
            #layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("Recouv_Rel_Num"), 0)
            #layer.commitChanges(False)
            # Mise en mémoire des variables
            idx_mh = layer.fields().indexOf("ID_MHH")
            idx_strate = layer.fields().indexOf("Strate")
            idx_abs = layer.fields().indexOf("Recouv_Abs_Num")
            idx_rel = layer.fields().indexOf("Recouv_Rel_Num")
            idx_dom = layer.fields().indexOf("Dom")

            # Dictionnaire pour tenir la somme Relatif par ID_MHH
            mh_sums = defaultdict(float)
            #mh_sums = {}

            # Calculer la somme Relatif par ID_MHH et par strate
            for feat in features:
                mh_id = feat.attributes()[idx_mh]
                #mh_id = feat.id()
                strate_val = feat.attributes()[idx_strate]
                abs_val = feat.attributes()[idx_abs]
                
                if abs_val is not None and abs_val != NULL:
                    # Step A: Ensure the outer layer is a dictionary
                    if mh_id not in mh_sums:
                        mh_sums[mh_id] = {}
                        
                    # Step B: Ensure the inner layer is a numeric starting point
                    if strate_val not in mh_sums[mh_id]:
                        mh_sums[mh_id][strate_val] = 0.0
                        
                    # Step C: Safe addition without sub-scripting conflicts!
                    mh_sums[mh_id][strate_val] += float(abs_val)
                else:
                    QMessageBox.information(None, "Donnée incomplète", "La ligne "+feat.id()+" du milieu humide "+mh_id+" ne possède pas de valeur de recouvrement absolu, rendant le calcul impossible.")
            # Liste pour tenir le résultat final
            attribute_updates = {}

            # Calcul de la proportion
            for feat in features:
                mh_id = feat.attributes()[idx_mh]
                strate_val = feat.attributes()[idx_strate]
                abs_val = feat.attributes()[idx_abs]
                
                #total_sum = mh_sums[mh_id][strate_val]
                total_sum = mh_sums.get(mh_id,{}).get(strate_val,0.0)
                
                if total_sum > 0 and abs_val is not None:
                    rel_val = (float(abs_val) / total_sum)*100
                else:
                    rel_val = 0.0  # S'assure de gérer la division par zéro et les cas limites

                # Stock la réponse pour application subséquente
                attribute_updates[feat.id()] = {idx_rel: rel_val}

            # Applique les modifications
            layer.startEditing()
            layer.dataProvider().changeAttributeValues(attribute_updates)
            layer.commitChanges()
            
            # Rafraichit la couche pour afficher les modifications dans l'interface
            layer.triggerRepaint()
            print(f"Mise à jour de {len(attribute_updates)} entités avec succès.")

            # Étape 1 : Réinitialisation de Dom
            print('etape1')
            ### Est-ce vraiment utile? En principe on recalcule tout, et ça élimine les entrées manuelles... Si le résultat est le même, retirer car écriture = lent
            features = list(layer.selectedFeatures() if apply_to_selection_only else layer.getFeatures())
            attribute_updates_2 = {}
            for feature in features:
                #layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("Dom"), 0)
                attribute_updates_2[feature.id()] = {idx_dom: 0}

            # Étape 2 : Calculs de dominance basés sur Recouv_Rel_Num
            print('etape2')
            cumulative_sums = {}
            for feature in features:
                id_mh, strate, recouv_abs, recouv_rel = feature["ID_MHH"], feature["Strate"], feature["Recouv_Abs_Num"], feature["Recouv_Rel_Num"]
                cumulative_sums.setdefault(id_mh, {}).setdefault(strate, []).append((feature.id(), recouv_rel, recouv_abs))

            # Vérification de la somme des Recouv_Abs_Num avant toute autre condition
            for id_mh, strates in cumulative_sums.items():
                for strate, values in strates.items():
                    total_recouv_abs = sum(recouv_abs for _, _, recouv_abs in values)

                    # Si la somme des Recouv_Abs_Num est inférieure à 10, on ne fait rien. Sinon, on caclule la dominance
                    ### Techniquement, si SOMME Recouv_Abs < 10, on ne calcule simplement pas la strate. Ici on exécute quand même l'étape 3, donc perte de temps
                    if total_recouv_abs >= 10:
                        values.sort(key=lambda x: x[2], reverse=True)  # Tri des entités par Recouv_Rel_Num décroissant
                        cum_sum, recouv_to_update = 0, set()

                        # Appliquer les règles de dominance sur Recouv_Rel_Num
                        for fid, recouv_rel, _ in values:
                            cum_sum += recouv_rel
                            recouv_to_update.add(recouv_rel)
                            if cum_sum > 50 and cum_sum - recouv_rel < 50:
                                ### Gérer le = 50
                                break

                        for fid, recouv_rel, _ in values:
                            if recouv_rel in recouv_to_update:
                                #layer.changeAttributeValue(fid, layer.fields().indexFromName("Dom"), 1)
                                if fid in attribute_updates_2:
                                    attribute_updates_2[fid][idx_dom] = 1
                                else:
                                    attribute_updates_2[feature.id()] = {idx_dom: 1}

                        # Étape 3 : Mettre Dom = 1 pour "Recouv_Rel_Num" >= 20
                        print('etape3')
                        #for feature in features:
                            #print(feature["Recouv_Rel_Num"])
                        for fid, recouv_rel_val, recouv_abs_val in values:
                            if recouv_rel_val >= 20:
                                #layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("Dom"), 1)
                                if fid in attribute_updates_2:
                                    attribute_updates_2[fid][idx_dom] = 1
                                else:
                                    attribute_updates_2[feature.id()] = {idx_dom: 1}

            # Étape 4 : Mettre à jour la table de strates végétales
            print('etape4')
            layer.startEditing()
            layer.dataProvider().changeAttributeValues(attribute_updates_2)
            layer.commitChanges()
            
            # Rafraichit la couche pour afficher les modifications dans l'interface
            layer.triggerRepaint()
            print(f"Mise à jour de {len(attribute_updates_2)} entités avec succès.")

            # Étape 5 : Mettre à jour les éléments du bilan d'espèces végétales
            print('etape5')
            ### bâtir une liste de ID_MHH, puis faire les modifications uniquement sur celles-ci, En fait, faire le calcul ici avant même d'aller écrire dans MH, donc récupérer Statut
            layer_MH = QgsProject.instance().mapLayersByName("Form_MHH")
            if not layer_MH:
                QMessageBox.critical(self, "Erreur", "La couche 'Form_MHH' n'est pas trouvée dans le projet.")
                return

            layer_MH = layer_MH[0]
            
            idx_mh_mh = layer_MH.fields().indexOf("ID_MHH")
            idx_vegh = layer_MH.fields().indexOf("Veg_DomH")
            idx_vegnh = layer_MH.fields().indexOf("Veg_DomNH")
            idx_bilveg = layer_MH.fields().indexOf("Bil_Veg")
            listeDom = {}
            listeAbs = {}
            
            uid_to_fid = {}
            for parent_feat in layer_MH.getFeatures():
                u_val = parent_feat.attributes()[idx_mh_mh]
                if u_val is not None:
                    uid_to_fid[u_val] = parent_feat.id()
            print(1)
            features = list(layer.selectedFeatures() if apply_to_selection_only else layer.getFeatures())
            for feature in features:
                id_mh, statut, dominance, recouv_abs = feature["ID_MHH"], feature["Statut"], feature["Dom"], feature["Recouv_Abs_Num"]
                
                if statut is None or statut == NULL:
                    statut = '-'
                if recouv_abs is None or recouv_abs == NULL:
                    QMessageBox.information(None, "Donnée incomplète", "La ligne "+feature.id()+" du milieu humide "+id_mh+" ne possède pas de valeur de recouvrement absolu, rendant le calcul impossible.")
                
                print('ID :'+id_mh)
                
                if id_mh in uid_to_fid:
                    mh_fid = uid_to_fid[id_mh]
                
                    print(2)
                    if mh_fid not in listeDom:
                        listeDom[mh_fid] = {idx_vegh:0,idx_vegnh:0,idx_bilveg:0}
                
                    if statut == 'OBL':
                        print('OBL')
                        if mh_fid in listeAbs:
                            actuel_listeAbs = listeAbs[mh_fid]['r_abs']
                            listeAbs[mh_fid]['r_abs'] = actuel_listeAbs + recouv_abs
                        else:
                            listeAbs[mh_fid] = {'r_abs':recouv_abs}
                
                    if str(dominance) == '1':
                        print('liste :'+str(listeDom[mh_fid]))
                        print('Statut :'+str(statut))
                        if statut in ('OBL','FACH'):
                            print('OBL2')
                            if mh_fid in listeDom:
                                actuel_listeDom = listeDom[mh_fid][idx_vegh]
                                listeDom[mh_fid][idx_vegh] = actuel_listeDom + 1
                            else:
                                listeDom[mh_fid] = {idx_vegh:1,idx_vegnh:0}
                        elif statut in ('NI'):
                            print('NI')
                            if mh_fid in listeDom:
                                actuel_listeDom = listeDom[mh_fid][idx_vegnh]
                                listeDom[mh_fid][idx_vegnh] = actuel_listeDom + 1
                            else:
                                listeDom[mh_fid] = {idx_vegh:0,idx_vegnh:1}
                        print('Fin :'+str(listeDom[mh_fid]))

            # Étape 6 : Vérifier le bilan des espèces végétales
            #print(listeDom)
            print('etape6')
            for objet,values in listeAbs.items():
                #print(objet)
                if values['r_abs'] >= 10:
                    #print('abs1')
                    if objet in listeDom:
                        #print('abs2')
                        listeDom[objet][idx_bilveg] = 1

            for objet,values in listeDom.items():
                #print(objet)
                if listeDom[objet][idx_bilveg] == 0:
                    if listeDom[objet][idx_vegh] > listeDom[objet][idx_vegnh]:
                        #print('A>B')
                        listeDom[objet][idx_bilveg] = 1
                    else:
                        #print('pouet')
                        listeDom[objet][idx_bilveg] = 0
                        
            # Étape 7 : Écrire les résultats finaux
            print('etape7')
            if listeDom:
                # Vérifier si la couche est modifiable
                if not layer_MH.isEditable():
                    layer_MH.startEditing()
                    layer_MH.dataProvider().changeAttributeValues(listeDom)
                    layer_MH.commitChanges()
                    layer_MH.triggerRepaint()
                
            #for feature in layer_MH.getFeatures():
                ### Ici aussi, vérifier si plus performant de faire en Python vs QGIS
                #layer_MH.changeAttributeValue(feature.id(), layer_MH.fields().indexFromName("Veg_DomH"), 0)
                #aggregate(layer:='FormSect_SP_Veget',aggregate:='count',expression:='Espece',filter:= ("ID_MHH"  =  attribute(@parent,'ID_MHH')) AND attribute(get_feature('Tbl_EspecesFlore','ID_SPP',"Espece"),'Statut hydrique') in ('OBL','FACH') AND "Dom" = '1')
                #layer_MH.changeAttributeValue(feature.id(), layer_MH.fields().indexFromName("Veg_DomNH"), 0)
                #aggregate(layer:='FormSect_SP_Veget',aggregate:='count',expression:='Espece',filter:= ("ID_MHH"  =  attribute(@parent,'ID_MHH')) AND attribute(get_feature('Tbl_EspecesFlore','ID_SPP',"Espece"),'Statut hydrique') in ('NI') AND "Dom" = '1')
                #layer_MH.commitChanges(False)
                #layer_MH.changeAttributeValue(feature.id(), layer_MH.fields().indexFromName("Bil_Veg"), 0)
                # if("Veg_DomH" >  "Veg_DomNH" ,1,if(aggregate(layer:='FormSect_SP_Veget',aggregate:='sum',expression:="Recouv_Abs_Num",filter:= ("ID_MHH"  =  attribute(@parent,'ID_MHH')) AND attribute(get_feature('Tbl_EspecesFlore','ID_SPP',"Espece"),'Statut hydrique') in ('OBL'))>=10,1,0))
                #layer_MH.commitChanges(False)

                QMessageBox.information(self, "Succès", "Les calculs ont été appliqués. N'oubliez pas d'enregistrer les modifications.")
            self.close()

        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Une erreur s'est produite : {e}")
            layer.rollBack()

class UpdateDomPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.widget = None

    def initGui(self):
        self.action = QAction(QIcon(""), "Calcul de la dominance", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Calcul de la dominance", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&Calcul de la dominance", self.action)

    def run(self):
        if not self.widget:
            self.widget = UpdateDomWidget()
        self.widget.show()