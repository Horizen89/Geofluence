from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QPushButton, QCheckBox, QMessageBox, QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject

class UpdateDomWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Calculer la dominance des espèces végétales")
        self.setMinimumWidth(450)
        self.setLayout(QVBoxLayout())

        # Case à cocher pour appliquer le calcul aux entités sélectionnées
        self.selection_only_checkbox = QCheckBox("Appliquer seulement aux entités sélectionnées")
        self.layout().addWidget(self.selection_only_checkbox)

        # Bouton pour lancer le calcul
        self.update_button = QPushButton("Lancer le calcul")
        self.update_button.clicked.connect(self.run_update)
        self.layout().addWidget(self.update_button)

    def run_update(self):
        layer = QgsProject.instance().mapLayersByName("FormSect_SP_Veget")
        if not layer:
            QMessageBox.critical(self, "Erreur", "La couche 'FormSect_SP_Veget' n'est pas trouvée dans le projet.")
            return

        layer = layer[0]

        # Vérifier si la couche est modifiable
        if not layer.isEditable():
            layer.startEditing()

        try:
            apply_to_selection_only = self.selection_only_checkbox.isChecked()
            features = list(layer.selectedFeatures() if apply_to_selection_only else layer.getFeatures())

            if not features:
                QMessageBox.warning(self, "Attention", "Aucune entité concernée pour le calcul.")
                return

            # Étape 1 : Réinitialisation de Dom
            for feature in features:
                layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("Dom"), 0)

            # Étape 2 : Calculs de dominance basés sur Recouv_Rel_Num
            cumulative_sums = {}
            for feature in features:
                id_mhh, strate, recouv_rel = feature["ID_MHH"], feature["Strate"], feature["Recouv_Rel_Num"]
                recouv_abs = feature["Recouv_Abs_Num"]  # Récupération de Recouv_Abs_Num
                cumulative_sums.setdefault(id_mhh, {}).setdefault(strate, []).append((feature.id(), recouv_rel, recouv_abs))

            # Vérification de la somme des Recouv_Abs_Num avant toute autre condition
            for id_mhh, strates in cumulative_sums.items():
                for strate, values in strates.items():
                    total_recouv_abs = sum(recouv_abs for _, _, recouv_abs in values)

                    # Si la somme des Recouv_Abs_Num est inférieure à 10, marquer toutes les entités comme non dominantes
                    if total_recouv_abs < 10:
                        for fid, _, _ in values:
                            layer.changeAttributeValue(fid, layer.fields().indexFromName("Dom"), 0)
                    else:
                        # Sinon, on applique les autres conditions (dominance par Recouv_Rel_Num)
                        values.sort(key=lambda x: x[1], reverse=True)  # Tri des entités par Recouv_Rel_Num décroissant
                        cum_sum, recouv_to_update = 0, set()

                        # Appliquer les règles de dominance sur Recouv_Rel_Num
                        for fid, recouv_rel, _ in values:
                            cum_sum += recouv_rel
                            recouv_to_update.add(recouv_rel)
                            if cum_sum > 50 and cum_sum - recouv_rel < 50:
                                break

                        for fid, recouv_rel, _ in values:
                            if recouv_rel in recouv_to_update:
                                layer.changeAttributeValue(fid, layer.fields().indexFromName("Dom"), 1)

            # Étape 3 : Mettre Dom = 1 pour "Recouv_Rel_Num" >= 20 si Recouv_Abs_Num est suffisant
            for feature in features:
                # On applique ce critère uniquement si la somme de Recouv_Abs_Num est >= 10
                if feature["Recouv_Abs_Num"] >= 10 and feature["Recouv_Rel_Num"] >= 20:
                    layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("Dom"), 1)

            QMessageBox.information(self, "Succès", "Les calculs ont été appliqués. N'oubliez pas d'enregistrer les modifications.")
            self.close()

        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Une erreur s'est produite : {e}")
            layer.rollBack()

class UpdateDomPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.widget = None

    def initGui(self):
        self.action = QAction(QIcon(""), "Calcul de la dominance", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Calcul de la dominance", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&Calcul de la dominance", self.action)

    def run(self):
        if not self.widget:
            self.widget = UpdateDomWidget()
        self.widget.show()